{{ config(
    materialized='incremental',
    unique_key='employee_id',
    sort='effective_date',
    dist='employee_id'
) }}

SELECT
    employee_id,
    salary,
    effective_date,
    last_updated
FROM {{ source('employee_source', 'employeesalary') }}

{% if is_incremental() %}
WHERE last_updated > (SELECT MAX(last_updated) FROM {{ this }})
{% endif %}
