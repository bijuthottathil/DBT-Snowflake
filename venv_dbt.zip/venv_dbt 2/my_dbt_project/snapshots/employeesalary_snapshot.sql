{% snapshot employeesalary_snapshot %}  

{{    
  config(      
    target_schema='magnumschema',      
    strategy='timestamp',      
    unique_key='employee_id',      
    updated_at='last_updated'   
  )  
}} 

select * 
from MAGNUMSCHEMA.employeesalary

{% endsnapshot %}